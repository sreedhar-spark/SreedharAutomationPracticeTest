package Utilities;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import org.openqa.selenium.TakesScreenshot;

public class ExtentReportUtility {

    ExtentReports extent;
    ExtentTest scenarioDef;
    ExtentTest features;

    String extentReportLocation = "C:\\Users\\sree\\IdeaProjects\\JavaCucumber\\target\\";
    String fileName = extentReportLocation + "extentreport.html";


    public void ExtentReport()
    {
        extent = new ExtentReports();
        ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter(fileName);
        htmlReporter.config().setTheme(Theme.DARK);
        htmlReporter.config().setDocumentTitle("Cucumber JVM Extent Report");
        htmlReporter.config().setEncoding("utf-8");
        htmlReporter.config().setReportName("Automation Practice Site Test Report");

        extent.attachReporter(htmlReporter);

    }

    public void ExtentReportScreenshot()
    {
        //var screen = ((TakesScreenshot)driver
    }

    public void FlushReport()
    {
        extent.flush();
    }
}
