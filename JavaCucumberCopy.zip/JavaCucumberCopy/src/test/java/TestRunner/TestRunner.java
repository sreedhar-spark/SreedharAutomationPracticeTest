/**
 * TestRunner.java - This class is created for running the tests by providing cucumber options.
 * @author  Sreedhar Guntala
 * @Date    09-02-2020
 * @version 1.0
 *
 **/
package TestRunner;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.AfterClass;
import org.junit.runner.RunWith;
import com.cucumber.listener.Reporter;

import java.io.File;

@RunWith(Cucumber.class)
@CucumberOptions(
            features = "Features",
            glue = "StepDefinitions",
            //plugin = {"pretty", "json:target/report.json", "de.monochromata.cucumber.report.PrettyReports:target/pretty-cucumber"}
            plugin = {"pretty", "html:target/cucumber-html-report", "json:target/cucumber.json",
                "json:target/cucumber.xml", "rerun:target/rerun.txt"}
            //plugin = {"com.cucumber.listener.ExtentCucumberFormatter:target/cucumberjvm-extent-reports/extentreport.html"}
            )

public class TestRunner {

    /*@AfterClass
    public static void writeExtentReport() {
        Reporter.loadXMLConfig(new File("/target/extent-config.xml"));
        Reporter.setSystemInfo("user", "Sreedhar");
        Reporter.setSystemInfo("os", "Windows 10");
        Reporter.setTestRunnerOutput("Sample test runner output message");
    }
    */
}
