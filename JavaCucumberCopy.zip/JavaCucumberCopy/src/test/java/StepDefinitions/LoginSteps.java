/**
 * LoginSteps.java - This class is created for developing the step definitions for all feature files.
 * @author  Sreedhar Guntala
 * @Date    09-02-2020
 * @version 1.0
 *
 **/
package StepDefinitions;

import cucumber.api.java.en.*;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class LoginSteps {

    static Logger log = Logger.getLogger(LoginSteps.class);

    WebDriver driver;

    WebElement signIn, emailAddress, password, signInButton, signOut;
    WebElement myAccountLabel,  tShirtsLink, tShirtProductImage, addToCartButton, proceedToCheckOutButton;
    WebElement proceedToCheckOutInCartSummary, proceedToCheckOutInAddressPage, proceedToCheckOutInShippingPage;
    WebElement termsOfServiceCheckbox, paymentMethodPaymentByBankWire, confirmOrderInOrderSummaryPage;
    WebElement backToOrdersInOrderConfirmation, newOrderReferenceInOrderHistory;
    WebElement myPersonalInformation, socialTitleMr, firstName, currentPassword, saveOption;
    WebElement personalInformationUpdateInfo, customerAccountName;

    String userEmailAddress = "SeleniumTesting@gmail.com";
    String userPassword = "Selenium123";

    @Given("I am on the login home page")
    public void i_am_on_the_login_home_page()
    {
        try {
            //System.setProperty("webdriver.chrome.driver", "C:/SeleniumDrivers/chromedriver.exe");
            System.setProperty("webdriver.chrome.driver", "src/test/java/Utilities/chromedriver.exe");
            driver = new ChromeDriver();
            driver.manage().window().maximize();
            driver.get("http://automationpractice.com");
            log.info("Navigating to automationpractice.com site");
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

            signIn = driver.findElement(By.partialLinkText("Sign in"));
            signIn.click();
            log.info("Sign in option clicked");
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        }
        catch(Exception e)
        {
            System.out.println("Exception occured in i_am_on_the_login_home_page() method " + e);
            log.error("Error occurred in i_am_on_the_login_home_page() method.");
        }
    }

    @When("I will enter email \"([^\"]*)\" and password \"([^\"]*)\"")
    public void i_will_enter_useremail_and_password_details(String emailId, String userPass)
    {
        try
        {
            emailAddress = driver.findElement(By.id("email"));
            emailAddress.clear();
            emailAddress.sendKeys(emailId);
            log.info("email address is entered : " + emailAddress);

            password = driver.findElement(By.id("passwd"));
            password.clear();
            password.sendKeys(userPass);
            log.info("password is entered : " + password);

            signInButton = driver.findElement(By.id("SubmitLogin"));
            signInButton.click();
            log.info("signin button clicked");

            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            log.info("i_will_enter_useremail_and_password_details() method called..");
        }
        catch(Exception e)
        {
            System.out.println("Exception occured in i_will_enter_useremail_and_password_details() method " + e);
            log.error("Error occurred in i_will_enter_useremail_and_password_details() method.");
        }
    }

    @Then("I should login successfully")
    public void i_should_login_successfully()
    {
        try
        {
            myAccountLabel = driver.findElement(By.xpath("//*[@id=\"center_column\"]/h1"));
            String myAccountLabelText = myAccountLabel.getText();
            log.info("Getting the My Account label text content : " + myAccountLabelText);

            Assert.assertEquals("MY ACCOUNT", myAccountLabelText);
            log.info("My Account label text content assertion done.");
            driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        }
        catch(Exception e)
        {
            System.out.println("Exception occured in i_should_login_successfully() method " + e);
            log.error("Error occurred in i_should_login_successfully() method.");
        }
    }

    @Then("I should be on My Account page")
    public void i_should_be_on_My_Account_page()
    {
        try
        {
            myAccountLabel = driver.findElement(By.xpath("//*[@id=\"center_column\"]/h1"));
            String myAccountLabelText = myAccountLabel.getText();
            log.info("Getting the My Account label text content.");

            Assert.assertEquals("MY ACCOUNT", myAccountLabelText);
            log.info("My Account label text content assertion done.");
        }
        catch(Exception e)
        {
            System.out.println("Exception occured in i_should_be_on_My_Account_page() method " + e);
            log.error("Error occurred in i_should_be_on_My_Account_page() method.");
        }
    }

    @Then("I click on \"([^\"]*)\" option in My Account page")
    public void i_click_on_T_shirts_option_in_My_Account_page(String tShirtOption)
    {
        try
        {
            //tShirtsLink = driver.findElement(By.partialLinkText("T-shirts"));
            tShirtsLink = driver.findElement(By.xpath("//*[@id=\"block_top_menu\"]/ul/li[3]/a"));
            tShirtsLink.click();
            log.info("Clicked on T-Shirts link option.");
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        }
        catch(Exception e)
        {
            System.out.println("Exception occured in i_click_on_T_shirts_option_in_My_Account_page() method " + e);
            log.error("Error occurred in i_click_on_T_shirts_option_in_My_Account_page() method.");
        }
    }

    @Then("I click on choosen Tshirt in Tshirts page")
    public void I_click_on_choosen_Tshirt_in_Tshirts_page()
    {
        try
        {
            tShirtProductImage = driver.findElement(By.className("product_img_link"));
            tShirtProductImage.click();
            log.info("Clicked on chosen T-shirt product image.");
            driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        }
        catch(Exception e)
        {
            System.out.println("Exception occured in I_click_on_choosen_Tshirt_in_Tshirts_page() method " + e);
            log.error("Error occurred in I_click_on_choosen_Tshirt_in_Tshirts_page() method.");
        }
    }

    @Then("I click on \"([^\"]*)\"")
    public void I_click_on_Add_to_Cart_option(String addToCartSelect)
    {
        try
        {
            driver.switchTo().frame(driver.findElement(By.xpath("//iframe[starts-with(@id, 'fancybox-frame')]")));
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            addToCartButton = driver.findElement(By.xpath("//*[@id=\"add_to_cart\"]/button/span"));
            addToCartButton.click();
            log.info("Clicked on 'Add to Cart' option.");
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        }
        catch(Exception e)
        {
            System.out.println("Exception occured in I_click_on_Add_to_Cart_option() method " + e);
            log.error("Error occurred in I_click_on_Add_to_Cart_option() method.");
        }
    }

    @Then("I click on Proceed to checkout option")
    public void I_click_on_Proceed_to_checkout_option()
    {
        try
        {
            Thread.sleep(10000);
            proceedToCheckOutButton = driver.findElement(By.xpath("//*[@id=\"layer_cart\"]/div[1]/div[2]/div[4]/a/span"));
            //proceedToCheckOutButton = driver.findElement(By.xpath("/html/body/div/div[1]/header/div[3]/div/div/div[4]/div[1]/div[2]/div[4]/a/span"));
            proceedToCheckOutButton.click();
            log.info("Clicked on 'Proceed to checkout' option.");
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        }
        catch(Exception e)
        {
            System.out.println("Exception occured in I_click_on_Proceed_to_checkout_option() method " + e);
            log.error("Error occurred in I_click_on_Proceed_to_checkout_option() method.");
        }
    }

    @Then("I click with \"([^\"]*)\" option")
    public void I_click_with_Proceed_to_checkout_option(String proceedToCheckout)
    {
        try
        {
            Thread.sleep(10000);
            proceedToCheckOutButton = driver.findElement(By.xpath("//*[@id=\"layer_cart\"]/div[1]/div[2]/div[4]/a/span"));
            proceedToCheckOutButton.click();
            log.info("Clicked on 'Proceed to checkout' option.");
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        }
        catch(Exception e)
        {
            System.out.println("Exception occured in I_click_with_Proceed_to_checkout_option() method " + e);
            log.error("Error occurred in I_click_with_Proceed_to_checkout_option() method.");
        }
    }

    @Then("I click \"([^\"]*)\" option in Shopping Cart summary page")
    public void I_click_on_Proceed_to_checkout_option_in_Shopping_Cart_summary_page(String proceedToCheckout)
    {
        try
        {
            proceedToCheckOutInCartSummary = driver.findElement(By.xpath("//*[@id=\"center_column\"]/p[2]/a[1]/span"));
            proceedToCheckOutInCartSummary.click();
            log.info("Clicked on 'Proceed to checkout' option in Shopping Cart summary page.");
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        }
        catch(Exception e)
        {
            System.out.println("Exception occured in I_click_on_Proceed_to_checkout_option_in_Shopping_Cart_summary_page() method " + e);
            log.error("Error occurred in I_click_on_Proceed_to_checkout_option_in_Shopping_Cart_summary_page() method.");
        }
    }

    @Then("I go with \"([^\"]*)\" option in Addresses page")
    public void I_go_with_Proceed_to_checkout_option_in_Addresses_page(String proceedToCheckout)
    {
        try {
            proceedToCheckOutInAddressPage = driver.findElement(By.xpath("//*[@id=\"center_column\"]/form/p/button/span"));
            proceedToCheckOutInAddressPage.click();
            log.info("Clicked on 'Proceed to checkout' option in Addresses page");
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        }
        catch(Exception e)
        {
            System.out.println("Exception occured in I_go_with_Proceed_to_checkout_option_in_Addresses_page() method " + e);
            log.error("Error occurred in I_go_with_Proceed_to_checkout_option_in_Addresses_page() method.");
        }
    }

    @Then("I choose \"([^\"]*)\" option in Shipping page")
    public void I_choose_Proceed_to_checkout_option_in_Shipping_page(String proceedToCheckout)
    {
        try
        {
            termsOfServiceCheckbox = driver.findElement(By.id("cgv"));
            termsOfServiceCheckbox.click();
            log.info("Selected the terms of service checkbox option.");

            proceedToCheckOutInShippingPage = driver.findElement(By.xpath("//*[@id=\"form\"]/p/button/span"));
            proceedToCheckOutInShippingPage.click();
            log.info("Clicked on 'Proceed to checkout' option in Shipping page");
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        }
        catch(Exception e)
        {
            System.out.println("Exception occured in I_choose_Proceed_to_checkout_option_in_Shipping_page() method " + e);
            log.error("Error occurred in I_choose_Proceed_to_checkout_option_in_Shipping_page() method.");
        }
    }

    @Then("I select \"([^\"]*)\" option in choose payment method page")
    public void I_select_Pay_by_bank_wire_option_in_choose_payment_method_page(String payBankByWire)
    {
        try
        {
            paymentMethodPaymentByBankWire = driver.findElement(By.partialLinkText("Pay by bank wire"));
            paymentMethodPaymentByBankWire.click();
            log.info("Clicked on 'Payment by bank wire' option in payment method page.");
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        }
        catch(Exception e)
        {
            System.out.println("Exception occured in I_select_Pay_by_bank_wire_option_in_choose_payment_method_page() method " + e);
            log.error("Error occurred in I_select_Pay_by_bank_wire_option_in_choose_payment_method_page() method.");
        }
    }

    @Then("I choose \"([^\"]*)\" option in order summary page")
    public void I_choose_I_confirm_by_order_option_in_order_summary_page(String confirmMyOrder)
    {
        try
        {
            confirmOrderInOrderSummaryPage = driver.findElement(By.xpath("//*[@id=\"cart_navigation\"]/button/span"));
            confirmOrderInOrderSummaryPage.click();
            log.info("Clicked on 'Confirm Order' option in order summary page.");
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        }
        catch(Exception e)
        {
            System.out.println("Exception occured in I_choose_I_confirm_by_order_option_in_order_summary_page() method " + e);
            log.error("Error occurred in I_choose_I_confirm_by_order_option_in_order_summary_page() method.");
        }
    }

    @Then("I proceed with \"([^\"]*)\" option in Order Confirmation page and Verify in Order History")
    public void I_proceed_with_Back_to_orders_option_in_Order_Confirmation_page_and_Verify_in_Order_History(String backToOrders)
    {
        try
        {
            boolean orderConfirmationTextPresent = driver.getPageSource().contains("Your order on My Store is complete");
            Assert.assertEquals(true, orderConfirmationTextPresent);
            log.info("Assertion done for Order confirmation text.");

            String orderReferenceWholeText = driver.getPageSource().toString();
            ArrayList<String> words = new ArrayList<>();

            Pattern pattern = Pattern.compile("\\b[A-Z]{9,}\\b");
            Matcher matchWord = pattern.matcher(orderReferenceWholeText);
            while (matchWord.find())
            {
                words.add(matchWord.group());
            }

            String[] matchwordArray = GetTheStringArray(words);

            String newOrderReferenceInOrderSummary = matchwordArray[0].toString();
            System.out.println("String array list content -->> " + matchwordArray[0].toString());
            log.info("String array list content is present.");

            backToOrdersInOrderConfirmation = driver.findElement(By.partialLinkText("Back to orders"));
            backToOrdersInOrderConfirmation.click();
            log.info("Clicked on 'Back to Orders' option.");
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

            newOrderReferenceInOrderHistory = driver.findElement(By.xpath("//*[@id=\"order-list\"]/tbody/tr[1]/td[1]/a"));
            String newOrderReferenceTextInOrderHistory = newOrderReferenceInOrderHistory.getText();

            Assert.assertEquals(newOrderReferenceInOrderSummary, newOrderReferenceTextInOrderHistory);
            System.out.println("Order reference - newOrderReferenceInOrderSummary -->> " + newOrderReferenceInOrderSummary);
            System.out.println("Order reference - newOrderReferenceTextInOrderHistory -->> " + newOrderReferenceTextInOrderHistory);
            log.info("Assertion is done for new order reference");
        }
        catch(Exception e)
        {
            System.out.println("Exception occured in I_proceed_with_Back_to_orders_option_in_Order_Confirmation_page_and_Verify_in_Order_History() method " + e);
            log.error("Error occurred in I_proceed_with_Back_to_orders_option_in_Order_Confirmation_page_and_Verify_in_Order_History() method.");
        }
    }

    @Then("I click on Sign out and close browser")
    public void I_click_on_Sign_out_and_close_browser()
    {
        try
        {
            signOut = driver.findElement(By.partialLinkText("Sign out"));
            signOut.click();
            log.info("Clicked on 'Sign out' option");
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            driver.quit();
            log.info("Quitting the Browser window.");
        }
        catch(Exception e)
        {
            System.out.println("Exception occured in I_click_on_Sign_out_and_close_browser() method " + e);
            log.error("Error occurred in I_click_on_Sign_out_and_close_browser() method.");
        }
    }

    @Then("I am on My Account home page with email \"([^\"]*)\" and password \"([^\"]*)\"")
    public void I_am_on_My_Account_home_page(String emailId, String userPass)
    {
        try
        {
            i_am_on_the_login_home_page();
            i_will_enter_useremail_and_password_details(emailId, userPass);
            i_should_login_successfully();
        }
        catch(Exception e)
        {
            System.out.println("Exception occured in I_am_on_My_Account_home_page() method " + e);
            log.error("Error occurred in I_am_on_My_Account_home_page() method.");
        }
    }

    @Then("I click on My Personal Information")
    public void I_click_on_My_Personal_Information()
    {
        try
        {
            myPersonalInformation = driver.findElement(By.xpath("//*[@id=\"center_column\"]/div/div[1]/ul/li[4]/a/span"));
            myPersonalInformation.click();
            log.info("Clicked on 'My Personal Informarion' link option");
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        }
        catch(Exception e)
        {
            System.out.println("Exception occured in I_click_on_My_Personal_Information() method " + e);
            log.error("Error occurred in I_click_on_My_Personal_Information() method.");
        }
    }

    @Then("I update first name as \"([^\"]*)\"")
    public void I_update_first_name_as(String updatedFirstName)
    {
        try
        {
            socialTitleMr = driver.findElement(By.id("id_gender1"));
            socialTitleMr.click();
            log.info("Selected Social Title radio button option.");

            firstName = driver.findElement(By.id("firstname"));
            firstName.clear();
            firstName.sendKeys(updatedFirstName);
            log.info("Entered the updated first name content.");

            currentPassword = driver.findElement(By.id("old_passwd"));
            currentPassword.clear();
            currentPassword.sendKeys("Selenium123");
            log.info("Entered the current password content.");
        }
        catch(Exception e)
        {
            System.out.println("Exception occured in I_update_first_name_as() method " + e);
            log.error("Error occurred in I_update_first_name_as() method.");
        }

    }

    @Then("I click on Save option")
    public void I_click_on_Save_option()
    {
        try
        {
            saveOption = driver.findElement(By.xpath("//*[@id=\"center_column\"]/div/form/fieldset/div[11]/button/span"));
            saveOption.click();
            log.info("Clicked on 'Save' option.");
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        }
        catch(Exception e)
        {
            System.out.println("Exception occured in I_click_on_Save_option() method " + e);
            log.error("Error occurred in I_click_on_Save_option() method.");
        }
    }

    @Then("I should see successfully updated information")
    public void I_should_see_successfully_updated_information()
    {
        try
        {
            personalInformationUpdateInfo = driver.findElement(By.xpath("//*[@id=\"center_column\"]/div/p\n"));
            String personalInformationUpdateText = personalInformationUpdateInfo.getText();
            String expectedPersonalInfoUpdateText = "Your personal information has been successfully updated.";

            Assert.assertEquals(expectedPersonalInfoUpdateText, personalInformationUpdateText);
            log.info("Assertion done for personal information successfully updated text.");
        }
        catch(Exception e)
        {
            System.out.println("Exception occured in I_should_see_successfully_updated_information() method " + e);
            log.error("Error occurred in I_should_see_successfully_updated_information() method.");
        }
    }

    @Then("I should see the updated first name \"([^\"]*)\" in personal information")
    public void I_should_see_the_updated_first_name_in_personal_information(String updatedFirstName)
    {
        try
        {
            customerAccountName = driver.findElement(By.xpath("//*[@id=\"header\"]/div[2]/div/div/nav/div[1]/a/span"));
            String customerAccountNameText = customerAccountName.getText();
            System.out.println("customerAccountNameText is -->> " + customerAccountNameText);
            log.info("Getting the Customer Account Name..");

            boolean updatedFirstNamePresent = customerAccountNameText.contains(updatedFirstName);
            System.out.println("updatedFirstNamePresent status is -->> " + updatedFirstNamePresent);
            log.info("Getting the updated firstname text present status..");
            Assert.assertEquals(true, customerAccountNameText.contains(updatedFirstName));
            log.info("Assertion done for the updated first name text present status..");
        }
        catch(Exception e)
        {
            System.out.println("Exception occured in I_should_see_the_updated_first_name_in_personal_information() method " + e);
            log.error("Error occurred in I_should_see_the_updated_first_name_in_personal_information() method.");
        }
    }

    //*****//
    @When("I will enter login details")
    public void i_will_enter_login_details()
    {
        try
        {
            emailAddress = driver.findElement(By.id("email"));
            emailAddress.clear();
            emailAddress.sendKeys(userEmailAddress);
            log.info("Entered user email address.");

            password = driver.findElement(By.id("passwd"));
            password.clear();
            password.sendKeys(userPassword);
            log.info("Entered user password.");

            signInButton = driver.findElement(By.id("SubmitLogin"));
            signInButton.click();
            log.info("Clicked on 'Sign in' option.");
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        }
        catch(Exception e)
        {
            System.out.println("Exception occured in i_will_enter_login_details() method " + e);
            log.error("Error occurred in i_will_enter_login_details() method.");
        }
    }

    @Then("I click on Tshirts option in My Account page")
    public void i_click_on_T_shirts_option_in_My_Account_page()
    {
        try
        {
            tShirtsLink = driver.findElement(By.xpath("//*[@id=\"block_top_menu\"]/ul/li[3]/a"));
            tShirtsLink.click();
            log.info("Clicked on 'T-Shirts' link option.");
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        }
        catch(Exception e)
        {
            System.out.println("Exception occured in i_click_on_T_shirts_option_in_My_Account_page() method " + e);
            log.error("Error occurred in i_click_on_T_shirts_option_in_My_Account_page() method.");
        }
    }

    @Then("I click on Add to Cart option")
    public void I_click_on_Add_to_Cart_option()
    {
        try
        {
            driver.switchTo().frame(driver.findElement(By.xpath("//iframe[starts-with(@id, 'fancybox-frame')]")));
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            addToCartButton = driver.findElement(By.xpath("//*[@id=\"add_to_cart\"]/button/span"));
            addToCartButton.click();
            log.info("Clicked on 'Add to Cart' option.");
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        }
        catch(Exception e)
        {
            System.out.println("Exception occured in I_click_on_Add_to_Cart_option() method " + e);
            log.error("Error occurred in I_click_on_Add_to_Cart_option() method.");
        }
    }

    @Then("I click on Proceed to checkout option in Shopping Cart summary page")
    public void I_click_on_Proceed_to_checkout_option_in_Shopping_Cart_summary_page()
    {
        try
        {
            proceedToCheckOutInCartSummary = driver.findElement(By.xpath("//*[@id=\"center_column\"]/p[2]/a[1]/span"));
            proceedToCheckOutInCartSummary.click();
            log.info("Clicked on 'Proceed to checkout' option in Shopping Cart summary page");
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        }
        catch(Exception e)
        {
            System.out.println("Exception occured in I_click_on_Proceed_to_checkout_option_in_Shopping_Cart_summary_page() method " + e);
            log.error("Error occurred in I_click_on_Proceed_to_checkout_option_in_Shopping_Cart_summary_page() method.");
        }
    }

    @Then("I click on Proceed to checkout option in Addresses page")
    public void I_click_on_Proceed_to_checkout_option_in_Addresses_page()
    {
        try
        {
            proceedToCheckOutInAddressPage = driver.findElement(By.xpath("//*[@id=\"center_column\"]/form/p/button/span"));
            proceedToCheckOutInAddressPage.click();
            log.info("Clicked on 'Proceed to checkout' option in Addresses page.");
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        }
        catch(Exception e)
        {
            System.out.println("Exception occured in I_click_on_Proceed_to_checkout_option_in_Addresses_page() method " + e);
            log.error("Error occurred in I_click_on_Proceed_to_checkout_option_in_Addresses_page() method.");
        }
    }

    @Then("I click on Proceed to checkout option in Shipping page")
    public void I_click_on_Proceed_to_checkout_option_in_Shipping_page()
    {
        try
        {
            termsOfServiceCheckbox = driver.findElement(By.id("cgv"));
            termsOfServiceCheckbox.click();
            log.info("Selected 'Terms of Service' checkbox option.");

            proceedToCheckOutInShippingPage = driver.findElement(By.xpath("//*[@id=\"form\"]/p/button/span"));
            proceedToCheckOutInShippingPage.click();
            log.info("Clicked on 'Proceed to checkout' option in Shipping page.");
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        }
        catch(Exception e)
        {
            System.out.println("Exception occured in I_click_on_Proceed_to_checkout_option_in_Shipping_page() method " + e);
            log.error("Error occurred in I_click_on_Proceed_to_checkout_option_in_Shipping_page() method.");
        }
    }

    @Then("I click on Pay by bank wire option in choose payment method page")
    public void I_click_on_Pay_by_bank_wire_option_in_choose_payment_method_page()
    {
        try
        {
            paymentMethodPaymentByBankWire = driver.findElement(By.partialLinkText("Pay by bank wire"));
            paymentMethodPaymentByBankWire.click();
            log.info("Clicked on 'Payment by bank wire' option in payment method page.");
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        }
        catch(Exception e)
        {
            System.out.println("Exception occured in I_click_on_Pay_by_bank_wire_option_in_choose_payment_method_page() method " + e);
            log.error("Error occurred in I_click_on_Pay_by_bank_wire_option_in_choose_payment_method_page() method.");
        }
    }

    @Then("I choose confirm my order option in order summary page")
    public void I_choose_confirm_by_order_option_in_order_summary_page()
    {
        try
        {
            confirmOrderInOrderSummaryPage = driver.findElement(By.xpath("//*[@id=\"cart_navigation\"]/button/span"));
            confirmOrderInOrderSummaryPage.click();
            log.info("Choosed 'Confirm my order' option in Order summary page.");
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        }
        catch(Exception e)
        {
            System.out.println("Exception occured in I_choose_confirm_by_order_option_in_order_summary_page() method " + e);
            log.error("Error occurred in I_choose_confirm_by_order_option_in_order_summary_page() method.");
        }
    }

    @Then("I click on Back to orders option in Order Confirmation page and Verify in Order History")
    public void I_click_on_Back_to_orders_option_in_Order_Confirmation_page_and_Verify_in_Order_History()
    {
        try
        {
            boolean orderConfirmationTextPresent = driver.getPageSource().contains("Your order on My Store is complete");
            Assert.assertEquals(true, orderConfirmationTextPresent);

            String orderReferenceWholeText = driver.getPageSource().toString();

            ArrayList<String> words = new ArrayList<>();

            Pattern pattern = Pattern.compile("\\b[A-Z]{9,}\\b");
            Matcher matchWord = pattern.matcher(orderReferenceWholeText);
            while (matchWord.find())
            {
                words.add(matchWord.group());
            }

            String[] matchwordArray = GetTheStringArray(words);

            String newOrderReferenceInOrderSummary = matchwordArray[0].toString();
            System.out.println("String array list content -->> " + matchwordArray[0].toString());

            backToOrdersInOrderConfirmation = driver.findElement(By.partialLinkText("Back to orders"));
            backToOrdersInOrderConfirmation.click();
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

            newOrderReferenceInOrderHistory = driver.findElement(By.xpath("//*[@id=\"order-list\"]/tbody/tr[1]/td[1]/a"));
            String newOrderReferenceTextInOrderHistory = newOrderReferenceInOrderHistory.getText();

            Assert.assertEquals(newOrderReferenceInOrderSummary, newOrderReferenceTextInOrderHistory);
            System.out.println("Order reference - newOrderReferenceInOrderSummary -->> " + newOrderReferenceInOrderSummary);
            System.out.println("Order reference - newOrderReferenceTextInOrderHistory -->> " + newOrderReferenceTextInOrderHistory);
        }
        catch(Exception e)
        {
            System.out.println("Exception occured in I_click_on_Back_to_orders_option_in_Order_Confirmation_page_and_Verify_in_Order_History() method " + e);
            log.error("Error occurred in I_click_on_Back_to_orders_option_in_Order_Confirmation_page_and_Verify_in_Order_History() method.");
        }
    }

    public static String[] GetTheStringArray(ArrayList<String> arr)
    {
          String text[] = new String[arr.size()];
            for (int i = 0; i < arr.size(); i++)
            {
                text[i] = arr.get(i);
            }
            return text;
    }

}
